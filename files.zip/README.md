# Music Galaxy

Map why artists connect, then fly through it in 3D. Open `galaxy.html` to see the sample galaxy.

## Quick start

    uv run galaxy.py --demo              # the sample galaxy, no network needed
    uv run galaxy.py "Radiohead"         # crawl Spotify from an artist, build galaxy.html and open it

`uv run` reads the dependencies listed at the top of `galaxy.py` and installs them (Python 3.11+).
Without uv: `pip install -r requirements.txt`, then `python galaxy.py ...`.

Useful options: `--depth 3`, `--max-nodes 300`, `--per-node 10`, `--credits 2` (top tracks per artist
read for song credits; 0 skips), `--no-crates`, `--no-playlists`, `--source lastfm` (set `LASTFM_API_KEY`),
`--source listenbrainz`, `--out my.html`. `python galaxy.py -h` lists everything. Crawls are cached in
`galaxy_cache.json`, so re-runs are quick; `--refresh-days` sets when cached artists are refetched.

## What you are looking at

- **Why artists connect.** Blue: fans overlap ("Fans also like"). Gold: recorded together (features,
  production, joint records). Rose: shared people (members, producers, writers). Teal: playlist
  neighbours. A pair with several reasons gets one strand per reason. Click any star for the details.
- **Sectors** are communities found with Louvain, named after their most distinctive genre tag.
- **Phenomena.** Black holes are listed by many artists but list few back. Wormholes are links between
  sectors that act as long-range shortcuts. Binary stars are each other's closest match. Stellar
  nurseries are tight knots of lesser-known artists. Rogue planets link across sectors but belong to
  none. Supernovae released something in the last 30 days (real crawls only).
- **Flight plan.** Pick two artists, and up to two stops on the way. The planner chooses the route and
  one track per artist so tempos and Camelot keys mix well. Copy the track links and paste them into a
  playlist in the Spotify desktop app, or download the set list.
- **Daily expedition.** Fly from one artist to another along links in as few jumps as possible. The
  destination is a beacon; you only see the star you are on and its links. Fuel is twice the shortest
  route, at least 6 jumps. A scan shows which links lead closer and uses 1 fuel. Results share as a
  spoiler-free grid. Everyone with the same galaxy file gets the same puzzle each day. Progress and
  streaks are saved in your browser, per galaxy file.

## How the expedition stays fair

Puzzles are picked when the galaxy is built, two years ahead:

- both artists are recognisable and never directly linked
- from 3 jumps up there are at least two shortest routes
- at least one shortest route runs only through reasonably well-known artists
- playlist links don't count as jumps
- no pair repeats until every fair pair has been used, and artists rest about ten days between appearances
- difficulty combines distance, how many first moves make progress, how hard the destination is to
  approach and how many best routes exist; it is ranked within each galaxy and rises through the week,
  so Monday is easiest and Sunday hardest

## The sample galaxy

202 artists from 11 scenes. Collaborations and shared personnel are real and documented; fan-overlap
lists, playlist links and star sizes are illustrative. Tempo and key come from a public 2020 dump of
Spotify's audio analysis (TidyTuesday, 2020-01-21). The curated source lives in `tools/build_demo.py`.

## Files

- `galaxy.py`: crawler, link reasons, sectors, phenomena, expedition calendar and renderer
- `viewer_template.html`: the page; `galaxy.py` inlines the assets into it
- `assets/galaxy_core.js`: expedition rules and the flight planner (shared with the tests)
- `assets/galaxy_engine.js`: 3d-force-graph 1.80.2, three.js 0.187.0 and the bloom pass in one bundle, so pages work offline
- `assets/galaxy_fonts.css`: Bodoni Moda and Archivo (SIL Open Font License)
- `assets/demo.json`: the sample galaxy's data
- `engine/`: rebuild the bundle with `npm ci && npm run build`
- `tests/`: `python -m pytest tests`, and after building the demo, `node --test tests/core.test.mjs`

## Notes

- SpotAPI uses Spotify's unofficial web-player endpoints. They can change without notice, and scraping
  may conflict with Spotify's terms. Fine for personal use; think twice before publishing crawls.
- Not yet tested against the live services: Spotify crawls (tested against SpotAPI's real model
  classes, not the network), Last.fm and ListenBrainz.
