#!/usr/bin/env python3
# /// script
# requires-python = ">=3.11"
# dependencies = ["spotapi>=2.1,<3"]
# ///
"""Music Galaxy: map why artists connect, then fly through it in 3D.

    uv run galaxy.py "Radiohead"                     crawl Spotify, build galaxy.html, open it
    python galaxy.py "Radiohead" --depth 3 --max-nodes 300
    python galaxy.py "Radiohead" --source lastfm      Last.fm similarity (set LASTFM_API_KEY)
    python galaxy.py "Radiohead" --source listenbrainz
    python galaxy.py --demo                           built-in sample galaxy, no network

Links carry their reasons: fans overlap, recorded together, shared people
(members, producers, writers) and playlist neighbours. The page also finds
cosmic phenomena, plans DJ-friendly flight paths from tempo and Camelot keys,
and runs a daily expedition puzzle.

Spotify data comes from SpotAPI's public, no-login catalogue (Python 3.11+).
`uv run` installs it automatically; otherwise `pip install -r requirements.txt`.
"""
from __future__ import annotations

import argparse
import asyncio
import bisect
import dataclasses
import datetime as dt
import hashlib
import html
import json
import math
import os
import random
import re
import sys
import time
import unicodedata
import urllib.error
import urllib.parse
import urllib.request
import webbrowser
from collections import Counter, defaultdict, deque
from dataclasses import dataclass, field
from pathlib import Path

HERE = Path(__file__).resolve().parent
ASSETS = HERE / "assets"
CACHE_VERSION = 2
ARTIST_URI = re.compile(r"spotify:artist:[A-Za-z0-9]{22}")
ARTIST_URL = re.compile(r"open\.spotify\.com/(?:intl-[a-z-]+/)?artist/([A-Za-z0-9]{22})")
CAMELOT = re.compile(r"^(1[0-2]|[1-9])([AB])$")
LINK_KINDS = ("fans", "collab", "people", "playlist")


# ---------------------------------------------------------------------------
# Data model shared by every source
# ---------------------------------------------------------------------------

@dataclass
class Artist:
    key: str                       # stable id: spotify:artist:..., lastfm:..., mbid:...
    name: str
    uri: str = ""                  # Spotify URI when known
    url: str = ""                  # external page when there is no Spotify URI
    image: str | None = None
    pop: float | None = None       # monthly listeners, listeners, or a sample size
    pop_kind: str | None = None
    tags: list[str] = field(default_factory=list)
    related: list[list] = field(default_factory=list)    # [key, name, score|None] in source order
    bio: str | None = None
    world_rank: int | None = None
    cities: list[list] = field(default_factory=list)     # [city, country, listeners]
    latest: dict | None = None                           # {"name", "date", "uri"}
    crate: list[list] = field(default_factory=list)      # [track name, uri, bpm, camelot]
    fetched: float = 0.0

    @classmethod
    def load(cls, d: dict) -> "Artist":
        names = {f.name for f in dataclasses.fields(cls)}
        return cls(**{k: v for k, v in d.items() if k in names})


@dataclass
class Evidence:
    """One reason two artists are linked, besides fans overlap."""
    a: str
    b: str
    kind: str        # collab | people | playlist
    detail: str
    weight: float = 1.0


def norm(text: str) -> str:
    text = unicodedata.normalize("NFKD", str(text)).encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+", "", text.replace("&", "and"))


def dig(obj, *names):
    """getattr chain that stops at the first None."""
    for n in names:
        if obj is None:
            return None
        obj = getattr(obj, n, None)
    return obj


def plain_bio(text: str | None, limit: int = 420) -> str | None:
    if not text:
        return None
    text = html.unescape(re.sub(r"<[^>]+>", "", text))
    text = re.sub(r"\s+", " ", text).strip()
    if len(text) > limit:
        cut = text[:limit].rsplit(" ", 1)[0]
        text = cut.rstrip(",;:") + "…"
    return text or None


def camelot_code(value) -> str | None:
    if not value:
        return None
    m = CAMELOT.match(str(value).strip().upper())
    return f"{int(m.group(1))}{m.group(2)}" if m else None


# ---------------------------------------------------------------------------
# Sources
# ---------------------------------------------------------------------------

class Source:
    name = "base"
    link_kinds = ("fans",)

    def __init__(self, log=print, concurrency: int = 4):
        self.log, self.concurrency = log, concurrency

    async def __aenter__(self):
        return self

    async def __aexit__(self, *exc):
        return False

    async def search(self, text: str) -> list[Artist]:
        raise NotImplementedError

    async def fetch(self, keys: list[str]) -> dict[str, Artist | Exception]:
        raise NotImplementedError

    async def enrich(self, artists: dict[str, Artist], extras: dict, options) -> list[Evidence]:
        return []

    def key_for(self, text: str) -> str | None:
        return None


async def bounded(items, fn, concurrency):
    """Run fn over items with a bounded worker pool; returns {item: result | Exception}."""
    sem, out = asyncio.Semaphore(max(1, concurrency)), {}

    async def one(item):
        async with sem:
            try:
                out[item] = await fn(item)
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # one failure must not sink the batch
                out[item] = exc

    await asyncio.gather(*(one(i) for i in items))
    return out


class SpotifySource(Source):
    """SpotAPI's typed public catalogue (no login)."""
    name = "spotify"
    link_kinds = LINK_KINDS

    def __init__(self, log=print, concurrency=4, cache_dir: Path | None = None, catalogue=None):
        super().__init__(log, concurrency)
        self.cache_dir, self.cat, self._owns = cache_dir, catalogue, catalogue is None

    async def __aenter__(self):
        if self.cat is None:
            try:
                from spotapi import Catalogue, ResponseCache
            except ImportError:
                raise SystemExit("SpotAPI isn't installed. Run:  uv run galaxy.py ...  or  "
                                 "pip install -r requirements.txt  (needs Python 3.11+)")
            cache = None
            if self.cache_dir:
                self.cache_dir.mkdir(parents=True, exist_ok=True)
                cache = ResponseCache(self.cache_dir, ttl=3 * 86400, max_entries=4096, max_bytes=4 << 20)
            self.cat = Catalogue(cache=cache)
            await self.cat.__aenter__()
        return self

    async def __aexit__(self, *exc):
        if self._owns and self.cat is not None:
            await self.cat.__aexit__(*exc)
        return False

    def key_for(self, text):
        if m := ARTIST_URI.search(text):
            return m.group(0)
        if m := ARTIST_URL.search(text):
            return f"spotify:artist:{m.group(1)}"
        return None

    async def search(self, text):
        results = await self.cat.search(text, types="artist", limit=10)
        out = []
        for a in getattr(results, "artists", None) or []:
            uri, name = getattr(a, "uri", ""), dig(a, "profile", "name")
            if ARTIST_URI.fullmatch(uri or "") and name:
                out.append(Artist(key=uri, name=name, uri=uri))
        return out

    async def fetch(self, keys):
        found = await bounded(keys, self.cat.get_artist, self.concurrency)
        return {k: (v if isinstance(v, Exception) else self.from_details(v)) for k, v in found.items()}

    @staticmethod
    def from_details(d) -> Artist:
        uri = d.uri
        stats = d.stats
        pop, kind = None, None
        if stats is not None and stats.monthly_listeners is not None:
            pop, kind = stats.monthly_listeners, "monthly listeners"
        elif stats is not None and stats.followers is not None:
            pop, kind = stats.followers, "followers"
        related = []
        for item in dig(d, "related_content", "related_artists", "items") or []:
            if ARTIST_URI.fullmatch(item.uri or "") and item.uri != uri:
                related.append([item.uri, dig(item, "profile", "name") or item.uri, None])
        sources = dig(d, "visuals", "avatar_image", "sources") or []
        image = None
        if sources:
            best = min(sources, key=lambda s: abs((s.width or 320) - 320))
            image = best.url
        cities = [[c.city, c.country, c.number_of_listeners]
                  for c in (dig(stats, "top_cities", "items") or [])[:3]]
        latest = None
        rel = dig(d, "discography", "latest")
        if rel is not None and rel.date is not None and rel.date.year:
            y, m, day = rel.date.year, rel.date.month or 1, rel.date.day or 1
            latest = {"name": rel.name, "uri": rel.uri, "date": f"{y:04d}-{m:02d}-{day:02d}",
                      "precise": bool(rel.date.month and rel.date.day)}
        return Artist(key=uri, name=dig(d, "profile", "name") or uri, uri=uri, image=image,
                      pop=pop, pop_kind=kind, related=related,
                      bio=plain_bio(dig(d, "profile", "biography", "text")),
                      world_rank=dig(stats, "world_rank"), cities=cities, latest=latest,
                      fetched=time.time())

    # -- enrichment: collaborations, shared people, playlist neighbours, DJ crates ----------

    async def enrich(self, artists, extras, options):
        keys = list(artists)
        ttl = options.refresh_days * 86400
        stale = lambda k, part: (part not in extras.get(k, {})
                                 or time.time() - extras[k].get("t_" + part, 0) > ttl)

        def keep(k, part, value):
            slot = extras.setdefault(k, {})
            slot[part], slot["t_" + part] = value, time.time()
        if options.playlists:
            need = [k for k in keys if stale(k, "playlists")]
            if need:
                self.log(f"  Reading 'Discovered on' playlists for {len(need)} artists")
                got = await bounded(need, self.cat.get_artist_discovered_on, self.concurrency)
                for k, res in got.items():
                    if not isinstance(res, Exception):
                        keep(k, "playlists", [[p.uri, p.name] for p in res if p is not None])
        if options.crates:
            need = [k for k in keys if stale(k, "radio")]
            if need:
                self.log(f"  Filling DJ crates from {len(need)} artist radio playlists")
                got = await bounded(need, self._radio_tracks, self.concurrency)
                for k, res in got.items():
                    if not isinstance(res, Exception):
                        keep(k, "radio", res)
        if options.credits > 0:
            need = [k for k in keys if stale(k, "credits")]
            if need:
                self.log(f"  Reading song credits for {len(need)} artists (top {options.credits} tracks each)")
                got = await bounded(need, lambda k: self._credits(k, options.credits), self.concurrency)
                for k, res in got.items():
                    if not isinstance(res, Exception):
                        keep(k, "credits", res)
        return evidence_from_extras(artists, extras)

    async def _radio_tracks(self, key):
        radio = await self.cat.get_radio(key)
        if radio is None:
            return []
        tracks = []
        agen = self.cat.get_playlist_tracks(radio.uri, limit=50)
        try:
            async for page in agen:
                for t in page:
                    artists = [[a.uri, dig(a, "profile", "name") or ""]
                               for a in (dig(t, "artists", "items") or []) if getattr(a, "uri", None)]
                    tracks.append([t.name, t.uri, t.bpm, camelot_code(t.camelot_key), artists])
                break                              # the first page is plenty for a crate
        finally:
            await agen.aclose()
        return tracks

    async def _credits(self, key, top_n):
        top = await self.cat.get_artist_top_tracks(key)
        out = []
        for track in list(top)[:top_n]:
            credits = await self.cat.get_track_credits(track.uri)
            out.append([track.name, track.uri, [[c.name, c.role, c.uri, dig(c, "role_group", "name")]
                                                 for c in credits.contributors]])
        return out


def evidence_from_extras(artists: dict[str, Artist], extras: dict) -> list[Evidence]:
    """Turn cached playlists, radio tracks and credits into crates and typed evidence."""
    evidence, in_galaxy = [], set(artists)
    names = {k: a.name for k, a in artists.items()}

    # DJ crates and co-credited tracks from radio playlists
    crates = defaultdict(dict)
    for owner, ex in extras.items():
        for name, uri, bpm, key, track_artists in ex.get("radio", []) if owner in in_galaxy else []:
            on = [a for a, _ in track_artists if a in in_galaxy]
            if bpm and key:
                for a in on:
                    crates[a].setdefault(uri, [name, uri, round(float(bpm), 1), key])
            for i in range(len(on)):
                for j in range(i + 1, len(on)):
                    evidence.append(Evidence(on[i], on[j], "collab", f"Both on '{name}'"))
    for k, a in artists.items():
        if crates.get(k):
            a.crate = list(crates[k].values())[:6]

    # Credits: credited galaxy artists are direct collaborators; other people are shared personnel
    person_role = re.compile(r"produc|writ|compos|lyric", re.I)
    people = defaultdict(lambda: {"name": "", "role": "", "artists": set()})
    for owner, ex in extras.items():
        if owner not in in_galaxy:
            continue
        for track_name, _uri, credits in ex.get("credits", []):
            for cname, role, curi, group in credits:
                if curi == owner or norm(cname) == norm(names[owner]):
                    continue
                if curi in in_galaxy:
                    what = (role or group or "credited").lower()
                    evidence.append(Evidence(owner, curi, "collab",
                                             f"{cname} is credited ({what}) on '{track_name}'"))
                    continue
                if not person_role.search(f"{role or ''} {group or ''}"):
                    continue
                pk = curi or "name:" + norm(cname)
                people[pk]["name"] = cname
                people[pk]["role"] = (role or group or "").lower()
                people[pk]["artists"].add(owner)
    for person in people.values():
        group = sorted(person["artists"])
        if 2 <= len(group) <= 8:                 # bigger groups are usually engineers, not a link
            for i in range(len(group)):
                for j in range(i + 1, len(group)):
                    role = f" ({person['role']})" if person["role"] else ""
                    evidence.append(Evidence(group[i], group[j], "people",
                                             f"Both worked with {person['name']}{role}"))

    # Playlist neighbours, weighted so huge generic playlists count for little
    holders = defaultdict(set)
    titles = {}
    for owner, ex in extras.items():
        if owner in in_galaxy:
            for puri, pname in ex.get("playlists", []):
                holders[puri].add(owner)
                titles[puri] = pname
    pair_w, pair_best = defaultdict(float), {}
    for puri, group in holders.items():
        if not 2 <= len(group) <= 25:
            continue
        w = 1 / math.log2(1 + len(group))
        group = sorted(group)
        for i in range(len(group)):
            for j in range(i + 1, len(group)):
                p = (group[i], group[j])
                pair_w[p] += w
                if p not in pair_best or len(group) < pair_best[p][0]:
                    pair_best[p] = (len(group), titles[puri])
    per_artist = Counter()
    for (a, b), w in sorted(pair_w.items(), key=lambda kv: -kv[1]):
        if w >= 0.45 and per_artist[a] < 4 and per_artist[b] < 4:
            per_artist[a] += 1
            per_artist[b] += 1
            evidence.append(Evidence(a, b, "playlist", f"Both discovered on '{pair_best[(a, b)][1]}'",
                                     weight=min(1.0, w)))
    return evidence


def playlist_names_by_artist(extras: dict) -> dict[str, list[str]]:
    return {k: [name for _u, name in ex.get("playlists", [])] for k, ex in extras.items()}


class HttpJson:
    """Tiny stdlib JSON client with a polite request interval."""

    def __init__(self, min_interval: float, user_agent: str):
        self.min_interval, self.ua = min_interval, user_agent
        self._lock, self._last = asyncio.Lock(), 0.0

    async def get(self, url: str, params: dict | None = None, tries: int = 4):
        if params:
            url += ("&" if "?" in url else "?") + urllib.parse.urlencode(params)
        for attempt in range(tries):
            async with self._lock:
                wait = self._last + self.min_interval - time.monotonic()
                if wait > 0:
                    await asyncio.sleep(wait)
                self._last = time.monotonic()
            try:
                return await asyncio.to_thread(self._get, url)
            except urllib.error.HTTPError as exc:
                if exc.code in (429, 500, 502, 503, 504) and attempt + 1 < tries:
                    await asyncio.sleep(2 ** attempt)
                    continue
                raise
            except (urllib.error.URLError, TimeoutError):
                if attempt + 1 < tries:
                    await asyncio.sleep(2 ** attempt)
                    continue
                raise

    def _get(self, url):
        req = urllib.request.Request(url, headers={"User-Agent": self.ua, "Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=20) as resp:
            return json.loads(resp.read().decode("utf-8"))


def as_list(value):
    if value is None:
        return []
    return value if isinstance(value, list) else [value]


LASTFM_PLACEHOLDER = "2a96cbd8b46e442fc41c2b86b821562f"


class LastfmSource(Source):
    """Last.fm's official API: similarity scores and listener tags. Needs LASTFM_API_KEY."""
    name = "lastfm"
    API = "https://ws.audioscrobbler.com/2.0/"

    def __init__(self, log=print, concurrency=4, api_key=None, http=None):
        super().__init__(log, concurrency)
        self.api_key = api_key or os.environ.get("LASTFM_API_KEY")
        if not self.api_key:
            raise SystemExit("Last.fm needs an API key. Get one free at https://www.last.fm/api/account/create "
                             "and set LASTFM_API_KEY.")
        self.http = http or HttpJson(0.22, "MusicGalaxy/2.0")

    async def call(self, method, **params):
        data = await self.http.get(self.API, {"method": method, "api_key": self.api_key,
                                              "format": "json", "autocorrect": 1, **params})
        if isinstance(data, dict) and data.get("error"):
            raise LookupError(data.get("message") or f"Last.fm error {data['error']}")
        return data

    @staticmethod
    def key(name):
        return "lastfm:" + name.strip().lower()

    async def search(self, text):
        data = await self.call("artist.search", artist=text, limit=8)
        hits = as_list(((data.get("results") or {}).get("artistmatches") or {}).get("artist"))
        return [Artist(key=self.key(h["name"]), name=h["name"], url=h.get("url", ""),
                       pop=float(h.get("listeners") or 0) or None, pop_kind="listeners") for h in hits]

    async def fetch(self, keys):
        async def one(key):
            name = key.split(":", 1)[1]
            info = (await self.call("artist.getInfo", artist=name)).get("artist") or {}
            sim = await self.call("artist.getSimilar", artist=name, limit=30)
            related = [[self.key(s["name"]), s["name"], float(s.get("match") or 0)]
                       for s in as_list((sim.get("similarartists") or {}).get("artist")) if s.get("name")]
            tags = [t["name"].lower() for t in as_list((info.get("tags") or {}).get("tag"))[:5] if t.get("name")]
            listeners = float((info.get("stats") or {}).get("listeners") or 0) or None
            return Artist(key=key, name=info.get("name") or name, url=info.get("url", ""),
                          pop=listeners, pop_kind="listeners" if listeners else None, tags=tags,
                          related=related, bio=plain_bio((info.get("bio") or {}).get("summary")),
                          fetched=time.time())
        return await bounded(keys, one, self.concurrency)

    async def top_tags(self, names: list[str]) -> dict[str, list[str]]:
        async def one(name):
            data = await self.call("artist.getTopTags", artist=name)
            return [t["name"].lower() for t in as_list((data.get("toptags") or {}).get("tag"))[:5]]
        got = await bounded(names, one, self.concurrency)
        return {n: v for n, v in got.items() if not isinstance(v, Exception)}


class ListenBrainzSource(Source):
    """ListenBrainz similar artists (CC0) plus MusicBrainz names, genres and member links."""
    name = "listenbrainz"
    link_kinds = ("fans", "collab", "people")
    LABS = "https://labs.api.listenbrainz.org/similar-artists/json"
    ALGO = "session_based_days_7500_session_300_contribution_5_threshold_10_limit_100_filter_True_skip_30"
    MB = "https://musicbrainz.org/ws/2/artist/"

    def __init__(self, log=print, concurrency=2, http=None):
        super().__init__(log, concurrency)
        contact = os.environ.get("MUSICBRAINZ_CONTACT", "local script")
        self.mb = http or HttpJson(1.1, f"MusicGalaxy/2.0 ( {contact} )")   # MusicBrainz asks for 1 req/s
        self.labs = http or HttpJson(0.3, "MusicGalaxy/2.0")
        self.rels: dict[str, list] = {}

    async def search(self, text):
        data = await self.mb.get(self.MB, {"query": f'artist:"{text}"', "fmt": "json", "limit": 8})
        out = []
        for a in data.get("artists", []):
            label = a["name"] + (f" ({a['disambiguation']})" if a.get("disambiguation") else "")
            out.append(Artist(key="mbid:" + a["id"], name=a["name"], url=f"https://musicbrainz.org/artist/{a['id']}",
                              bio=label))
        return out

    async def fetch(self, keys):
        async def one(key):
            mbid = key.split(":", 1)[1]
            meta = await self.mb.get(self.MB + mbid, {"inc": "genres+tags+artist-rels", "fmt": "json"})
            rows = await self.labs.get(self.LABS, {"artist_mbids": mbid, "algorithm": self.ALGO})
            flat = []
            for r in as_list(rows):
                flat.extend(as_list(r) if isinstance(r, list) else [r])
            sims = [r for r in flat if isinstance(r, dict) and r.get("artist_mbid") and r.get("artist_mbid") != mbid
                    and r.get("score") is not None]
            sims.sort(key=lambda r: -float(r["score"]))
            top = float(sims[0]["score"]) if sims else 1.0
            related = [["mbid:" + r["artist_mbid"], r.get("name") or r["artist_mbid"], float(r["score"]) / top]
                       for r in sims[:30]]
            genres = sorted(meta.get("genres") or meta.get("tags") or [], key=lambda g: -g.get("count", 0))
            self.rels[key] = [[rel.get("type", ""), "mbid:" + rel["artist"]["id"], rel["artist"].get("name", "")]
                              for rel in meta.get("relations", []) if rel.get("artist")]
            return Artist(key=key, name=meta.get("name") or mbid, url=f"https://musicbrainz.org/artist/{mbid}",
                          tags=[g["name"].lower() for g in genres[:5]], related=related, fetched=time.time())
        return await bounded(keys, one, self.concurrency)

    async def enrich(self, artists, extras, options):
        evidence = []
        for k in artists:
            if k in self.rels:
                extras.setdefault(k, {})["rels"] = self.rels[k]
            for rtype, other, oname in extras.get(k, {}).get("rels", []):
                if other in artists and other != k:
                    kind = "people" if "member" in rtype else "collab"
                    detail = (f"{artists[k].name} and {oname}: {rtype}" if rtype else f"Linked on MusicBrainz")
                    evidence.append(Evidence(k, other, kind, detail.replace("member of band", "member of the band")))
        return evidence


# ---------------------------------------------------------------------------
# Crawling: layer by layer, the most-referenced artists first when space runs out
# ---------------------------------------------------------------------------

class CrawlState:
    def __init__(self):
        self.nodes: dict[str, Artist] = {}
        self.dist: dict[str, int] = {}


async def crawl(source: Source, seed: str, depth: int, max_nodes: int, per_node: int,
                cache: dict[str, Artist], refresh_days: float, state: CrawlState, log=print,
                save=lambda: None):
    now = time.time()
    fresh = lambda a: a is not None and now - (a.fetched or 0) < refresh_days * 86400
    layer, level = [seed], 0
    state.dist[seed] = 0
    while layer and len(state.nodes) < max_nodes:
        need = [k for k in layer if not fresh(cache.get(k))]
        log(f"Hop {level}: {len(layer)} artists ({len(layer) - len(need)} cached)")
        got = await source.fetch(need) if need else {}
        for k in layer:
            a = got.get(k, cache.get(k))
            if isinstance(a, Exception) or a is None:
                if k == seed:
                    raise SystemExit(f"Couldn't fetch the seed artist: {a}")
                log(f"  skipped {k}: {type(a).__name__}: {a}")
                continue
            if not isinstance(got.get(k), Exception) and k in got:
                cache[k] = a
            state.nodes[k] = a
            if len(state.nodes) >= max_nodes:
                break
        save()
        if level >= depth:
            break
        refs, best = Counter(), {}
        for k in layer:
            if k not in state.nodes:
                continue
            for rank, (rk, _rn, _s) in enumerate(state.nodes[k].related[:per_node]):
                if rk not in state.dist:
                    refs[rk] += 1
                    best[rk] = min(best.get(rk, 99), rank)
        room = max_nodes - len(state.nodes)
        layer = sorted(refs, key=lambda r: (-refs[r], best[r], r))[:room]
        level += 1
        for r in layer:
            state.dist[r] = level
    if seed in state.nodes and not state.nodes[seed].related:
        raise SystemExit(f"Fetched {state.nodes[seed].name} but the source returned no related artists.")
    return state.nodes


def load_cache(path: Path, source: str):
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}, {}
    if data.get("version") != CACHE_VERSION or data.get("source") != source:
        return {}, {}
    return ({k: Artist.load(v) for k, v in data.get("artists", {}).items()}, data.get("extras", {}))


def save_cache(path: Path, source: str, artists: dict[str, Artist], extras: dict):
    try:
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_text(json.dumps({"version": CACHE_VERSION, "source": source,
                                   "artists": {k: dataclasses.asdict(a) for k, a in artists.items()},
                                   "extras": extras}, ensure_ascii=False), encoding="utf-8")
        tmp.replace(path)
    except OSError as exc:
        print(f"  (couldn't write cache: {exc})")


# ---------------------------------------------------------------------------
# Graph algorithms
# ---------------------------------------------------------------------------

def louvain(n: int, edges: dict[tuple[int, int], float], resolution=1.0, seed=7) -> list[int]:
    """Louvain community detection (same moves as networkx's implementation), deterministic."""
    rng = random.Random(seed)
    membership = list(range(n))
    graph = {i: {} for i in range(n)}
    for (u, v), w in edges.items():
        graph[u][v] = graph[u].get(v, 0) + w
        if u != v:
            graph[v][u] = graph[v].get(u, 0) + w
    while True:
        nodes = sorted(graph)
        degree = {u: sum(graph[u].values()) + graph[u].get(u, 0) for u in nodes}
        m = sum(degree.values()) / 2
        if m == 0:
            break
        com = {u: i for i, u in enumerate(nodes)}
        stot = {i: degree[u] for i, u in enumerate(nodes)}
        order = nodes[:]
        rng.shuffle(order)
        improved, moves = False, 1
        while moves:
            moves = 0
            for u in order:
                cur, deg = com[u], degree[u]
                w2c = defaultdict(float)
                for v, w in graph[u].items():
                    if v != u:
                        w2c[com[v]] += w
                stot[cur] -= deg
                remove = -w2c[cur] / m + resolution * stot[cur] * deg / (2 * m * m)
                best, best_gain = cur, 0.0
                for c, w in sorted(w2c.items()):
                    gain = remove + w / m - resolution * stot[c] * deg / (2 * m * m)
                    if gain > best_gain + 1e-12:
                        best, best_gain = c, gain
                stot[best] += deg
                if best != cur:
                    com[u] = best
                    moves += 1
                    improved = True
        if not improved:
            break
        labels = {c: i for i, c in enumerate(sorted(set(com.values())))}
        membership = [labels[com[membership[v]]] for v in range(n)]
        nxt = {i: {} for i in labels.values()}
        for u in nodes:
            for v, w in graph[u].items():
                if u > v:
                    continue
                a, b = labels[com[u]], labels[com[v]]
                nxt[a][b] = nxt[a].get(b, 0) + w
                if a != b:
                    nxt[b][a] = nxt[b].get(a, 0) + w
        if len(nxt) == len(graph):
            break
        graph = nxt
    return membership


def modularity(n, edges, labels, resolution=1.0):
    deg, m = [0.0] * n, 0.0
    for (u, v), w in edges.items():
        deg[u] += w
        deg[v] += w
        m += w
    inner, tot = defaultdict(float), defaultdict(float)
    for (u, v), w in edges.items():
        if labels[u] == labels[v]:
            inner[labels[u]] += w
    for u in range(n):
        tot[labels[u]] += deg[u]
    return sum(inner[c] / m - resolution * (tot[c] / (2 * m)) ** 2 for c in tot) if m else 0.0


def bfs(adj, src, allow=None):
    """Distances from src; with allow, only expands through allowed nodes (targets still count)."""
    dist = [-1] * len(adj)
    dist[src] = 0
    q = deque([src])
    while q:
        u = q.popleft()
        if allow is not None and u != src and not allow[u]:
            continue
        for v in adj[u]:
            if dist[v] < 0:
                dist[v] = dist[u] + 1
                q.append(v)
    return dist


def path_counts(adj, dist_to_t):
    """sigma[u] = number of shortest paths from u to the target that dist_to_t measures."""
    order = sorted((u for u in range(len(adj)) if dist_to_t[u] >= 0), key=lambda u: dist_to_t[u])
    sigma = [0] * len(adj)
    for u in order:
        if dist_to_t[u] == 0:
            sigma[u] = 1
            continue
        sigma[u] = sum(sigma[v] for v in adj[u] if dist_to_t[v] == dist_to_t[u] - 1)
    return sigma


def percentiles(values):
    """Rank-based percentile in [0, 1] (ties share the average rank)."""
    idx = sorted(range(len(values)), key=lambda i: values[i])
    out, i = [0.0] * len(values), 0
    while i < len(idx):
        j = i
        while j + 1 < len(idx) and values[idx[j + 1]] == values[idx[i]]:
            j += 1
        p = ((i + j) / 2) / max(1, len(values) - 1)
        for k in range(i, j + 1):
            out[idx[k]] = p
        i = j + 1
    return out


# ---------------------------------------------------------------------------
# Building the galaxy
# ---------------------------------------------------------------------------

SPECIAL_WORDS = {"idm": "IDM", "uk": "UK", "r&b": "R&B", "edm": "EDM", "dj": "DJ", "us": "US", "lo-fi": "lo-fi"}


def tag_title(tag: str) -> str:
    words = [SPECIAL_WORDS.get(w, w) for w in tag.strip().split()]
    first = words[0] if words[0] in SPECIAL_WORDS.values() else words[0][:1].upper() + words[0][1:]
    return " ".join([first] + words[1:])


def name_sectors(groups, nodes, playlist_names):
    """Name each sector after its most distinctive tag, else a shared playlist, else its hub."""
    n = len(nodes)
    df = Counter(t for nd in nodes for t in set(nd["tags"]))
    used, names = set(), []
    pl_df = Counter(p for nd in nodes for p in set(playlist_names.get(nd["key"], [])))
    for members, hub in groups:
        best, best_score = None, 0.0
        tf = Counter(t for i in members for t in set(nodes[i]["tags"]))
        for t, c in tf.items():
            share = c / len(members)
            idf = math.log((n + 1) / (df[t] + 1))
            score = share * idf * idf if share >= 0.18 else 0    # favour specific genres over broad ones
            if score > best_score and t not in used:
                best, best_score = t, score
        if best:
            used.add(best)
            names.append(tag_title(best))
            continue
        ptf = Counter(p for i in members for p in set(playlist_names.get(nodes[i]["key"], [])))
        pick = None
        for p, c in ptf.most_common():
            outside = pl_df[p] - c
            if c / len(members) >= 0.3 and outside <= c and p not in used and not re.search(r"\bthis is\b|radio", p, re.I):
                pick = p
                break
        if pick:
            used.add(pick)
            names.append(pick)
        else:
            names.append(f"{nodes[hub]['name']} sector")
    return names


def build_galaxy(artists: dict[str, Artist], evidence: list[Evidence], seed_key: str, title: str,
                 per_node: int, playlist_names=None, dist=None, demo=False, note=None, source="spotify",
                 build_date: dt.date | None = None, calendar_days=730) -> dict:
    keys = list(artists)
    if seed_key in keys:
        keys.remove(seed_key)
        keys.insert(0, seed_key)
    idx = {k: i for i, k in enumerate(keys)}
    n = len(keys)
    nodes = []
    for k in keys:
        a = artists[k]
        nodes.append({"key": k, "name": a.name, "uri": a.uri if ARTIST_URI.fullmatch(a.uri or "") else "",
                      "url": a.url, "img": a.image if (a.image or "").startswith("https://") else None,
                      "pop": a.pop, "pk": a.pop_kind, "tags": a.tags[:5], "bio": a.bio,
                      "rank": a.world_rank, "cities": a.cities, "latest": a.latest,
                      "crate": [t for t in a.crate if camelot_code(t[3]) and t[2]][:6]})

    # --- fans overlap from ranked related lists -------------------------------------------
    fans = {}
    for k in keys:
        rel = artists[k].related[:per_node]
        for rank, (rk, _name, score) in enumerate(rel):
            if rk not in idx or rk == k:
                continue
            s = float(score) if score is not None else max(0.2, 1 - rank / 20)
            a, b = idx[k], idx[rk]
            p = (min(a, b), max(a, b))
            entry = fans.setdefault(p, {"s": [None, None], "r": [-1, -1]})
            side = 0 if a < b else 1          # side 0: smaller id lists the larger id
            entry["s"][side] = s
            entry["r"][side] = rank
    pairs = defaultdict(dict)
    for p, e in fans.items():
        s1, s2 = e["s"]
        if s1 is not None and s2 is not None:
            s = min(1.0, max(s1, s2) + 0.15 * min(s1, s2))
            mutual = 1
        else:
            s, mutual = 0.8 * (s1 if s1 is not None else s2), 0
        pairs[p]["fans"] = {"s": round(s, 3), "r": e["r"], "m": mutual}

    # --- collaborations, shared people, playlist neighbours ------------------------------
    for ev in evidence:
        if ev.a not in idx or ev.b not in idx or ev.a == ev.b:
            continue
        a, b = idx[ev.a], idx[ev.b]
        p = (min(a, b), max(a, b))
        if ev.kind == "playlist":
            cur = pairs[p].get("playlist")
            if not cur or ev.weight > cur["s"]:
                pairs[p]["playlist"] = {"s": round(ev.weight, 3), "d": ev.detail}
        else:
            details = pairs[p].setdefault(ev.kind, [])
            if ev.detail not in details and len(details) < 4:
                details.append(ev.detail)

    out_pairs, weights, exp_adj = [], {}, [set() for _ in range(n)]
    for (a, b), kinds in sorted(pairs.items()):
        w = (kinds["fans"]["s"] if "fans" in kinds else 0) \
            + (min(1.0, 0.8 + 0.1 * len(kinds["collab"])) if "collab" in kinds else 0) \
            + (0.7 if "people" in kinds else 0) + (0.35 * kinds["playlist"]["s"] if "playlist" in kinds else 0)
        eligible = any(k in kinds for k in ("fans", "collab", "people"))
        out_pairs.append({"a": a, "b": b, "w": round(min(w, 2.0), 3), "x": 1 if eligible else 0, "k": kinds})
        weights[(a, b)] = min(w, 2.0)
        if eligible:
            exp_adj[a].add(b)
            exp_adj[b].add(a)
    adj_all = [set() for _ in range(n)]
    for a, b in weights:
        adj_all[a].add(b)
        adj_all[b].add(a)

    # --- sectors (Louvain), tiny groups folded into their strongest neighbour -----------
    labels = louvain(n, weights, seed=7)
    for _ in range(2):
        sizes = Counter(labels)
        for i in range(n):
            if sizes[labels[i]] < 3:
                score = Counter()
                for (a, b), w in weights.items():
                    if i in (a, b):
                        j = b if a == i else a
                        if sizes[labels[j]] >= 3:
                            score[labels[j]] += w
                if score:
                    old = labels[i]
                    labels[i] = max(score.items(), key=lambda kv: (kv[1], -kv[0]))[0]
                    sizes[old] -= 1
                    sizes[labels[i]] += 1
    order = [lbl for lbl, _ in sorted(Counter(labels).items(), key=lambda kv: (-kv[1], kv[0]))]
    remap = {lbl: c for c, lbl in enumerate(order)}
    labels = [remap[x] for x in labels]
    strength = [0.0] * n
    for (a, b), w in weights.items():
        strength[a] += w
        strength[b] += w
    groups = []
    for c in range(len(order)):
        members = [i for i in range(n) if labels[i] == c]
        hub = max(members, key=lambda i: (strength[i], -i))
        groups.append((members, hub))
    sector_names = name_sectors(groups, nodes, playlist_names or {})
    sectors = [{"name": sector_names[c], "size": len(m), "hub": hub} for c, (m, hub) in enumerate(groups)]

    # --- popularity: size and recognisability ---------------------------------------------
    raw = [nd["pop"] for nd in nodes]
    have = [i for i in range(n) if raw[i]]
    sample = demo or any(nd["pk"] == "sample" for nd in nodes)
    if len(have) >= max(3, n // 3):
        vals = [(raw[i] if sample else math.log10(max(raw[i], 1))) for i in have]
        lo, hi = min(vals), max(vals)
        pct = percentiles(vals)
        size, ps = [None] * n, [None] * n
        for j, i in enumerate(have):
            size[i] = (vals[j] - lo) / (hi - lo) if hi > lo else 0.5
            ps[i] = pct[j]
        deg_pct = percentiles([len(adj_all[i]) for i in range(n)])
        for i in range(n):
            if size[i] is None:
                size[i], ps[i] = 0.25 * deg_pct[i], 0.5 * deg_pct[i]
    else:
        deg_pct = percentiles([strength[i] for i in range(n)])
        size, ps = deg_pct[:], deg_pct[:]
    if dist is None:
        dist = {k: 0 for k in keys}
    for i, nd in enumerate(nodes):
        nd.update({"id": i, "c": labels[i], "d": dist.get(keys[i], 0), "size": round(size[i], 3),
                   "ps": round(ps[i], 3), "deg": len(adj_all[i])})

    phenomena = find_phenomena(n, keys, artists, idx, pairs, exp_adj, labels, ps, per_node, sectors)
    fp = fingerprint(keys, out_pairs)
    expedition = plan_expeditions(exp_adj, ps, labels, fp, build_date or dt.date.today(), calendar_days)
    for nd in nodes:
        nd.pop("key")
    return {"v": 2, "title": title, "demo": demo, "note": note, "source": source, "seed": 0,
            "built": (build_date or dt.date.today()).isoformat(), "fp": fp,
            "nodes": nodes, "pairs": out_pairs, "sectors": sectors,
            "phenomena": phenomena, "expedition": expedition}


def fingerprint(keys, pairs) -> str:
    h = hashlib.sha1()
    for k in sorted(keys):
        h.update(k.encode())
    for p in pairs:
        if p["x"]:
            h.update(f"{keys[p['a']]}|{keys[p['b']]}".encode())
    return h.hexdigest()[:12]


# ---------------------------------------------------------------------------
# Cosmic phenomena
# ---------------------------------------------------------------------------

def find_phenomena(n, keys, artists, idx, pairs, exp_adj, labels, ps, per_node, sectors):
    # Directed fans graph inside the galaxy
    lists = {i: [idx[r[0]] for r in artists[keys[i]].related[:per_node] if r[0] in idx] for i in range(n)}
    in_deg, back = Counter(), Counter()
    for i, outs in lists.items():
        for j in outs:
            in_deg[j] += 1
            if i in lists.get(j, []):
                back[j] += 1

    # Black holes: listed by many, list few of them back
    ins = sorted(in_deg.values()) or [0]
    p90 = ins[int(0.9 * (len(ins) - 1))]
    holes = []
    for j, c in in_deg.items():
        recip = back[j] / c if c else 1
        if c >= max(5, p90) and recip <= 0.5:
            holes.append((c * (1 - recip), j, c, back[j]))
    holes.sort(reverse=True)
    black_holes = [{"id": j, "in": c, "back": b} for _s, j, c, b in holes[:max(1, round(n / 60))]]

    # Wormholes: links between sectors that are long-range shortcuts
    worms = []
    for (a, b), kinds in pairs.items():
        if labels[a] == labels[b] or not (b in exp_adj[a]):
            continue
        exp_adj[a].discard(b)
        exp_adj[b].discard(a)
        d = bfs(exp_adj, a)[b]
        exp_adj[a].add(b)
        exp_adj[b].add(a)
        detour = d if d > 0 else 99
        if detour >= 4:
            s = kinds.get("fans", {}).get("s", 0.4) + (0.6 if "collab" in kinds else 0) + (0.4 if "people" in kinds else 0)
            worms.append((min(detour, 9) * s, a, b, detour))
    worms.sort(reverse=True)
    wormholes, used = [], Counter()
    for _s, a, b, detour in worms:
        if used[a] or used[b]:
            continue
        used[a] += 1
        used[b] += 1
        wormholes.append({"a": a, "b": b, "detour": detour if detour < 99 else None})
        if len(wormholes) >= max(2, min(8, n // 28)):
            break

    # Binary stars: each is the other's closest match
    first = {i: (artists[keys[i]].related[0][0] if artists[keys[i]].related else None) for i in range(n)}
    mutual_first = []
    for i in range(n):
        j = idx.get(first[i])
        if j is not None and j > i and first[j] == keys[i]:
            kinds = pairs.get((i, j), {})
            bond = ("collab" in kinds) + ("people" in kinds)     # a real-world bond outranks a statistical one
            mutual_first.append((-bond, -(ps[i] + ps[j]), i, j))
    mutual_first.sort()
    binaries = [[i, j] for _b, _p, i, j in mutual_first[:max(3, round(n / 25))]]

    # Stellar nurseries: tight knots of lesser-known artists
    small = [i for i in range(n) if ps[i] <= 0.4]
    small_set = set(small)
    tri_adj = defaultdict(set)
    for i in small:
        for j in exp_adj[i]:
            if j in small_set and j > i and (exp_adj[i] & exp_adj[j] & small_set):
                tri_adj[i].add(j)
                tri_adj[j].add(i)
    seen, nurseries = set(), []
    for i in sorted(tri_adj):
        if i in seen:
            continue
        comp, q = [], [i]
        seen.add(i)
        while q:
            u = q.pop()
            comp.append(u)
            for v in tri_adj[u]:
                if v not in seen:
                    seen.add(v)
                    q.append(v)
        if len(comp) >= 3:
            edges = sum(1 for u in comp for v in tri_adj[u] if v > u)
            density = 2 * edges / (len(comp) * (len(comp) - 1))
            if density >= 0.4:
                nurseries.append({"ids": sorted(comp), "density": round(density, 2)})
    nurseries.sort(key=lambda x: (-len(x["ids"]), x["ids"]))
    nurseries = nurseries[:4]

    # Rogue planets: links spread across sectors, at home in none
    rogues = []
    for i in range(n):
        nb = exp_adj[i]
        if len(nb) < 3:
            continue
        by = Counter(labels[j] for j in nb)
        part = 1 - sum((c / len(nb)) ** 2 for c in by.values())
        own = by.get(labels[i], 0) / len(nb)
        if part >= 0.6 and own <= 0.34 and len(by) >= 3:
            rogues.append((part, i, [c for c, _ in by.most_common(3)]))
    rogues.sort(reverse=True)
    rogue_planets = [{"id": i, "sectors": s} for _p, i, s in rogues[:max(2, n // 50)]]
    return {"blackholes": black_holes, "wormholes": wormholes, "binaries": binaries,
            "nurseries": nurseries, "rogues": rogue_planets}


# ---------------------------------------------------------------------------
# Daily expedition calendar: fair, varied, harder towards the weekend
# ---------------------------------------------------------------------------

WEEKDAY_QUANTILE = {0: 0.12, 1: 0.27, 2: 0.42, 3: 0.55, 4: 0.67, 5: 0.80, 6: 0.92}
WEEKDAY_TIER = {0: 0, 1: 0, 2: 1, 3: 1, 4: 2, 5: 2, 6: 3}      # easy, medium, hard, expert
KNOWN_INTERMEDIATE = 0.25
RECOGNISABLE_END = 0.45


def expedition_candidates(adj, ps, labels, end_min=RECOGNISABLE_END):
    n = len(adj)
    comp_src = max(range(n), key=lambda u: len(adj[u])) if n else 0
    comp_dist = bfs(adj, comp_src)
    comp = [u for u in range(n) if comp_dist[u] >= 0]
    in_comp = [d >= 0 for d in comp_dist]
    dist = {u: bfs(adj, u) for u in comp}
    known = [ps[u] >= KNOWN_INTERMEDIATE for u in range(n)]
    kdist = {u: bfs(adj, u, allow=known) for u in comp}
    sigma = {t: path_counts(adj, dist[t]) for t in comp}
    ends = [u for u in comp if ps[u] >= end_min and len(adj[u]) >= 2 and in_comp[u]]
    cands = []
    for s in ends:
        for t in ends:
            if s == t:
                continue
            d = dist[t][s]
            if d < 2 or d > 6:
                continue
            sig = sigma[t][s]
            if d >= 3 and sig < 2:
                continue                                  # never a single gotcha route
            if kdist[s][t] != d:
                continue                                  # an optimal route must exist via known artists
            p_start = sum(1 for v in adj[s] if dist[t][v] == d - 1) / len(adj[s])
            p_end = sum(1 for v in adj[t] if dist[s][v] == d - 1) / len(adj[t])
            same = labels[s] == labels[t]
            diff = (d + 0.9 * (1 - p_start) + 0.6 * (1 - p_end) + 0.8 / math.sqrt(sig)
                    - (0.35 if same else 0.0) + 0.25 * (1 - min(ps[s], ps[t])))
            cands.append((round(diff, 4), s, t, d, same))
    cands.sort()
    return cands


def plan_expeditions(adj, ps, labels, fp, start: dt.date, days=730, practice=240):
    if len(adj) < 8:
        return None
    cands = expedition_candidates(adj, ps, labels)
    if len(cands) < 30:
        cands = expedition_candidates(adj, ps, labels, end_min=0.2)
    if len(cands) < 10:
        return None
    diffs = [c[0] for c in cands]
    quant = lambda q: diffs[min(len(diffs) - 1, int(q * (len(diffs) - 1)))]
    used_pairs, last_used, out = set(), {}, []
    prev_sectors = None
    for k in range(days):
        date = start + dt.timedelta(days=k)
        wd = date.weekday()
        target = quant(WEEKDAY_QUANTILE[wd])
        rng = random.Random(f"{fp}:{date.isoformat()}")
        pick, width, relax = None, 40, 0
        i = bisect.bisect_left(diffs, target)
        while pick is None:
            window = cands[max(0, i - width): i + width]
            scored = sorted(window, key=lambda c: abs(c[0] - target) + 0.35 * rng.random())
            for diff, s, t, d, _same in scored:
                if frozenset((s, t)) in used_pairs:
                    continue
                if relax < 1 and (k - last_used.get(s, -99) <= 10 or k - last_used.get(t, -99) <= 10):
                    continue
                if relax < 1 and prev_sectors == frozenset((labels[s], labels[t])):
                    continue
                pick = (s, t, d)
                break
            if pick is None:
                if width < len(cands):
                    width *= 2
                elif relax == 0:
                    relax = 1                               # small galaxies: allow artists back sooner
                else:
                    used_pairs.clear()                      # every fair pair used: start a new cycle
        s, t, d = pick
        used_pairs.add(frozenset((s, t)))
        last_used[s] = last_used[t] = k
        prev_sectors = frozenset((labels[s], labels[t]))
        out.append([s, t, d, WEEKDAY_TIER[wd]])
    soon = {frozenset((s, t)) for s, t, _d, _q in out[:60]}
    rng = random.Random(f"{fp}:practice")
    pool = [c for c in cands if frozenset((c[1], c[2])) not in soon]
    rng.shuffle(pool)
    practice_list = []
    for diff, s, t, d, _same in sorted(pool[:practice], key=lambda c: c[0]):
        q = bisect.bisect_left(diffs, diff) / max(1, len(diffs) - 1)
        tier = 0 if q < 0.3 else 1 if q < 0.6 else 2 if q < 0.85 else 3
        practice_list.append([s, t, d, tier])
    return {"start": start.isoformat(), "days": out, "practice": practice_list,
            "rules": {"fuel": "2x shortest, at least 6", "known": KNOWN_INTERMEDIATE, "ends": RECOGNISABLE_END}}


# ---------------------------------------------------------------------------
# Demo galaxy (assets/demo.json): real collaborations, illustrative fan lists
# ---------------------------------------------------------------------------

def demo_inputs():
    data = json.loads((ASSETS / "demo.json").read_text(encoding="utf-8"))
    key = lambda name: "demo:" + norm(name)
    artists = {}
    for a in data["artists"]:
        artists[key(a["name"])] = Artist(
            key=key(a["name"]), name=a["name"], pop=a["pop"], pop_kind="sample", tags=a["tags"],
            related=[[key(r), r, None] for r in a["related"]],
            crate=[[t["name"], t["uri"], t["bpm"], t["key"]] for t in data["crates"].get(a["name"], [])])
    ev = [Evidence(key(c["a"]), key(c["b"]), "collab", c["detail"]) for c in data["collabs"]]
    for p in data["people"]:
        group = p["artists"]
        for i in range(len(group)):
            for j in range(i + 1, len(group)):
                ev.append(Evidence(key(group[i]), key(group[j]), "people",
                                   f"Both worked with {p['person']} ({p['role']})"))
    ev += [Evidence(key(m["a"]), key(m["b"]), "people", m["detail"]) for m in data["members"]]
    for pl in data["playlists"]:
        g = pl["artists"]
        w = 1 / math.log2(1 + len(g))
        for i in range(len(g)):
            for j in range(i + 1, len(g)):
                ev.append(Evidence(key(g[i]), key(g[j]), "playlist",
                                   f"Both on the sample playlist '{pl['name']}'", weight=round(2.4 * w, 3)))
    seed = key(data["seed"])
    dist = {seed: 0}
    q = deque([seed])
    while q:
        u = q.popleft()
        for r, _n, _s in artists[u].related:
            if r in artists and r not in dist:
                dist[r] = dist[u] + 1
                q.append(r)
    for k in artists:
        dist.setdefault(k, max(dist.values()) + 1)
    return artists, ev, seed, dist, data


def demo_graph(build_date=None):
    artists, ev, seed, dist, data = demo_inputs()
    return build_galaxy(artists, ev, seed, data["title"], per_node=10, dist=dist, demo=True,
                        note=data["note"], source="demo", build_date=build_date)


# ---------------------------------------------------------------------------
# Rendering
# ---------------------------------------------------------------------------

def render(graph: dict, out_path: Path, template: Path | None = None):
    tpl = (template or HERE / "viewer_template.html").read_text(encoding="utf-8")
    script = lambda name: (ASSETS / name).read_text(encoding="utf-8").replace("</script", "<\\/script")
    blob = json.dumps(graph, ensure_ascii=False, separators=(",", ":")).replace("<", "\\u003c")
    parts = {"__TITLE__": html.escape(graph["title"] + " galaxy"),
             "/*__FONTS__*/": (ASSETS / "galaxy_fonts.css").read_text(encoding="utf-8"),
             "/*__ENGINE__*/": script("galaxy_engine.js"), "/*__CORE__*/": script("galaxy_core.js"),
             "__GALAXY_JSON__": blob}
    # one pass over the template only, so inserted data is never scanned for placeholders
    page = re.sub("|".join(map(re.escape, parts)), lambda m: parts[m.group(0)], tpl)
    Path(out_path).write_text(page, encoding="utf-8", newline="\n")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def make_source(args, log):
    if args.source == "lastfm":
        return LastfmSource(log, args.concurrency)
    if args.source == "listenbrainz":
        return ListenBrainzSource(log, min(args.concurrency, 2))
    return SpotifySource(log, args.concurrency, cache_dir=Path(args.cache).resolve().parent / ".spotapi_cache")


async def choose_seed(source, text, args, log):
    key = source.key_for(text)
    if key:
        return key
    hits = await source.search(text)
    if not hits:
        raise SystemExit(f"No artist found for {text!r}. Try the exact name or paste a Spotify artist link.")
    exact = [h for h in hits if norm(h.name) == norm(text)]
    pool = exact if exact else hits[:6]
    if len(pool) == 1 or (args.first and pool):
        return pool[0].key
    interactive = sys.stdin.isatty() and not args.first
    if exact and len(exact) == 1:
        return exact[0].key
    details = {}
    if isinstance(source, SpotifySource):
        got = await source.fetch([h.key for h in pool[:5]])
        details = {k: v for k, v in got.items() if not isinstance(v, Exception)}
    if not interactive:
        names = ", ".join(f"{h.name} [{h.key}]" for h in pool[:4])
        log(f"Several matches for {text!r}: {names}. Using the first; pass its link or URI to pick another.")
        return pool[0].key
    print(f"\nSeveral artists match {text!r}:")
    for i, h in enumerate(pool[:6], 1):
        d = details.get(h.key)
        extra = f"{int(d.pop):,} {d.pop_kind}" if d and d.pop else (h.bio or "")
        print(f"  {i}. {h.name}  {extra}")
    while True:
        choice = input(f"Which one? [1-{min(6, len(pool))}, Enter for 1]: ").strip() or "1"
        if choice.isdigit() and 1 <= int(choice) <= min(6, len(pool)):
            return pool[int(choice) - 1].key


async def run_crawl(args, state: CrawlState):
    log = print
    cache_path = Path(args.cache)
    cache, extras = load_cache(cache_path, args.source)
    async with make_source(args, log) as source:
        seed = await choose_seed(source, args.seed, args, log)
        print(f"Crawling from {seed}: {args.depth} hops, up to {args.max_nodes} artists, "
              f"{args.per_node} links each")
        try:
            await crawl(source, seed, args.depth, args.max_nodes, args.per_node, cache,
                        args.refresh_days, state, log, save=lambda: save_cache(cache_path, args.source, cache, extras))
            print("Finding why they connect")
            evidence = await source.enrich(state.nodes, extras, args)
        finally:
            save_cache(cache_path, args.source, cache, extras)
    tags_from = args.tags
    if tags_from == "auto":
        tags_from = "lastfm" if os.environ.get("LASTFM_API_KEY") and args.source != "lastfm" else "none"
    if tags_from == "lastfm" and args.source != "lastfm":
        print("Fetching genre tags from Last.fm for sector names")
        lf = LastfmSource(log, args.concurrency)
        tags = await lf.top_tags([a.name for a in state.nodes.values()])
        for a in state.nodes.values():
            a.tags = tags.get(a.name, a.tags)
    title = state.nodes[seed].name
    return build_galaxy(state.nodes, evidence, seed, title, args.per_node,
                        playlist_names=playlist_names_by_artist(extras), dist=state.dist, source=args.source)


def parse_args(argv=None):
    p = argparse.ArgumentParser(description="Map why artists connect, then fly through it in 3D.")
    p.add_argument("seed", nargs="?", help="artist name, Spotify artist URI, or open.spotify.com artist link")
    p.add_argument("--demo", action="store_true", help="build the built-in sample galaxy (no network)")
    p.add_argument("--source", choices=("spotify", "lastfm", "listenbrainz"), default="spotify")
    p.add_argument("--depth", type=int, default=2, help="hops from the seed artist (1-4, default 2)")
    p.add_argument("--max-nodes", type=int, default=200, help="stop after this many artists (default 200, max 600)")
    p.add_argument("--per-node", type=int, default=10, help="related artists followed per artist (default 10)")
    p.add_argument("--concurrency", type=int, default=4, help="parallel requests (default 4, max 8)")
    p.add_argument("--credits", type=int, default=2, help="top tracks per artist to read credits from (0 = skip)")
    p.add_argument("--no-crates", dest="crates", action="store_false", help="skip DJ crates (tempo and key)")
    p.add_argument("--no-playlists", dest="playlists", action="store_false", help="skip playlist neighbours")
    p.add_argument("--tags", choices=("auto", "lastfm", "none"), default="auto",
                   help="genre tags for sector names (auto uses Last.fm when LASTFM_API_KEY is set)")
    p.add_argument("--refresh-days", type=float, default=14, help="refetch cached artists older than this")
    p.add_argument("--first", action="store_true", help="never ask which artist you meant")
    p.add_argument("--out", default="galaxy.html", help="output file (default galaxy.html)")
    p.add_argument("--cache", default="galaxy_cache.json", help="cache file so re-runs are fast")
    p.add_argument("--no-open", action="store_true", help="don't open the result in a browser")
    args = p.parse_args(argv)
    args.depth = max(1, min(args.depth, 4))
    args.max_nodes = max(10, min(args.max_nodes, 600))
    args.per_node = max(3, min(args.per_node, 20))
    args.concurrency = max(1, min(args.concurrency, 8))
    args.credits = max(0, min(args.credits, 5))
    args.refresh_days = max(0.0, args.refresh_days)
    return args


def main(argv=None):
    try:
        sys.stdout.reconfigure(errors="replace")
    except Exception:
        pass
    args = parse_args(argv)
    state = CrawlState()
    if args.demo:
        graph = demo_graph()
    else:
        if not args.seed:
            raise SystemExit('Give me an artist, e.g.  python galaxy.py "Radiohead"   (or try --demo)')
        try:
            graph = asyncio.run(run_crawl(args, state))
        except KeyboardInterrupt:
            if len(state.nodes) < 5:
                raise SystemExit("\nStopped before enough artists were fetched.")
            print(f"\nStopped. Rendering the {len(state.nodes)} artists fetched so far.")
            seed = next(iter(state.dist))
            graph = build_galaxy(state.nodes, [], seed, state.nodes[seed].name if seed in state.nodes
                                 else "Partial", args.per_node, dist=state.dist, source=args.source)
    out = Path(args.out)
    render(graph, out)
    ph = graph["phenomena"]
    print(f"\n{len(graph['nodes'])} artists, {len(graph['pairs'])} links, {len(graph['sectors'])} sectors, "
          f"{len(ph['blackholes'])} black holes, {len(ph['wormholes'])} wormholes -> {out.resolve()}")
    if not args.no_open:
        webbrowser.open(out.resolve().as_uri())


if __name__ == "__main__":
    main()
